module.exports = function(grunt){

    grunt.initConfig({

        browserSync: {
          dev1: {
              bsFiles: {
                  src : [
                      'dev/css/*.css',
                      'dev/index.html',
                      'dev/js/*.js'

                  ]
              },
              options: {
                  watchTask: true,
                  // liverload: true,
                  server: './dev'
              }
          }
        },

        autoprefixer: {
            dist: {
                files: {
                    'dev/css/result_autoPre.css': 'dev/css/result.css'
                }
            }
          },

        processhtml: {
          dist:{
            files:{
              'build/index.html' : ['build/index.html'],
              'build/script.js' : ['build/script.js']
            }
          }
        },
        

        copy: {
          main: {
            expand: true,
            cwd: 'dev/images',
            src: '**',
            dest: 'build/images',
            flatten: true,
            filter: 'isFile',
          },
          main2: {
            expand: true,
            cwd: 'dev',
            src: 'index.html',
            dest: 'build/',
            flatten: true,
            filter: 'isFile',
          },
        },

        clean: {
            build: {
              src: ['dev/css/result.css']
            }
        },

        concat: {
          distCSS: {
            src: ['dev/css/*.css'],
            dest: 'build/style.css',
          },
          distJS: {
              src: ['dev/js/*.js'],
              dest: 'build/script.js',
            }
      },

        watch: {
            less: {
                files: ['dev/less/*.less'],
                tasks: ['less' , 'autoprefixer' , 'clean']
            }
        },


        less: {
            development: {
              options: {
                paths: ['dev/less/']
              },
              files: {
                'dev/css/result.css': 'dev/less/*.less'
              }
          }
        }
    });

    

    grunt.loadNpmTasks('grunt-browser-sync');
    grunt.loadNpmTasks('grunt-processhtml');
    grunt.loadNpmTasks('grunt-autoprefixer');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-concat');

    grunt.registerTask('default', ['browserSync' , 'watch']);
    grunt.registerTask('build', ['concat', 'copy', 'processhtml']);
    

}





